import numpy as np
import matplotlib.pyplot as plt

p = 0.4
empurrao = 1